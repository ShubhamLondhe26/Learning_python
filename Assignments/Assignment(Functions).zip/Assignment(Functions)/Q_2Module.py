#2)Create on module named ad Arithmetic which contains 4 functions as Add() for addition, Sub() for Subtraction, Mult() for multiplication and Div() for division. All functions accepts two parameters as number and perform operation. Write on python program which call all the functions from Arithmetic module by accepting the parameters from user

def addition(num1,num2):
    num=num1+num2
    return num
def subtraction(num1,num2):
    num=num1-num2
    return num
def multiplication(num1,num2):
    num=num1*num2
    return num
def divison(num1,num2):
    num=num1/num2
    return num
