#1)Write a program that accepts the name of the person and display it as given below
#Output : 
#What is your name? Shreya
#6

name=input("Enter your name: ")
print("What is your name?",name)