#3)Expected Output
#Enter value: shreya
#Enter value shreya and its <class 'str'>
#----------------------------------------
#Enter value:23
#Enter value 23 and its <class 'str'>
#----------------------------------------
#Enter value:23
#Enter value 23 and its <class 'int'>
#----------------------------------------
#Enter value:23.4
#Enter value 23.4 and its <class 'float'>#

string1=input("Enter your Name: ")
string2="23"
string3=int(input("Enter value: "))
string4=float(input("Enter value: "))

print(string1,type(string1))
print(string2,type(string2))
print(string3,type(string3))
print(string4,type(string4))





