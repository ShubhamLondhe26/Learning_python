#4)Write a program which accept two numbers from user 
#Enter the first number:6
#Enter the second number:7

#Addition of 6 and 7: 13.0

#Subtraction of 6 and 7: -1

#floordivision of 6 and 7: 0.0

#multiplication of 6 and 7: 42#

num1=float(input("Enter the first number: "))
num2=float(input("Enter the second number: "))

print(f"Addition of {num1} and {num2}: ",num1+num2)
print(f"Subtraction of {num1} and {num2}: ",num1-num2)
print(f"floordivision of {num1} and {num2}: ",num1//num2)
print(f"multiplication of {num1} and {num2}: ",num1*num2)
