#1.Write a program to print sum of first 10 Even Numbers 

for i in range(0,21,2):
      print("first 10 even numbers are: ",i)
