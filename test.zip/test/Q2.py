#2.Write a program to find the product of the digits of a number accepted from the user

num=int(input("Enter the Number: "))
sum=0
while (num>0):
    sum=
    num=num//10